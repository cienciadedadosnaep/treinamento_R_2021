# Salvador 19 de Julho de 2021
# Autor: Robson Wilson Silva Pessoa


#install.packages('tidyverse')
library(readr)
dados <- read_csv("data/all_data_v00.csv", 
                  col_types = cols(X1 = col_integer(), 
                  id = col_integer(), date = col_date(format = "%Y-%m-%d")), 
                  locale = locale(encoding = "ISO-8859-1"))

library(dplyr)

# Remocao da variavel X1
dados_v01 <- select(dados,-X1)

# Conhecer o banco 

names(dados_v01)
# listagem dos valores no console
dados_v01$aisp

# Transformar a variavel em fator as.factor() 
# e depois listar  os niveis levels()
levels(as.factor(dados_v01$aisp))

# pipe %>%
# gºf(x) = g(f(x))

# x     operador selecao  
dados_v02 <- dados_v01 %>% group_by(aisp,ano) %>% 
              select(homicidios) %>% 
              summarise(sum(homicidios))

# Breve visualizacao

library(ggplot2)

names(dados_v02) <- c("aisp","ano","homicidio_anual")  
names(dados_v02)
# grafico nao aprovado 
ggplot(dados_v02,aes(x=ano,y=homicidio_anual)) +
   geom_point()
 
# grafico de barras
ggplot(dados_v02,aes(x=ano,y=homicidio_anual,fill=aisp)) +
geom_bar(stat="identity")

# grafico de barras
ggplot(dados_v02) +
  geom_line(aes(x=ano,y=homicidio_anual,color=aisp))

# dplyr para filtrar ano de 2020

typeof(dados_v02$ano)

dados_v02 %>% filter(ano<2020) %>% ggplot() + 
  geom_line(aes(x=ano,y=homicidio_anual,color=aisp))

dados_v02 %>% filter(ano %in% c(2015,2018)) %>% ggplot() + 
  geom_line(aes(x=ano,y=homicidio_anual,color=aisp))

dados_v02 %>% filter(aisp=="AISP 01 - Barris") %>%
  filter(ano %in% c(2015,2018)) %>% 
  select(aisp,ano,homicidio_anual) %>%
  summarise(ano=as.character(ano),homicidio_anual) %>%
  ggplot(aes(x=ano,y=homicidio_anual)) + 
  geom_bar(stat="identity")


dados_v03 <- dados_v01 %>% 
  mutate(total_roub_oni_veic=roubo_onibus+roubo_veiculos) 

# Atividade - calculo dos percentuais de homicidios 
#  por AISP em um determinado mes 






